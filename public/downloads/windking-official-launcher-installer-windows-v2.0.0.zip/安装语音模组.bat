@echo off
setlocal
chcp 65001 >nul
title WindKing Fabric and Voice Chat Installer
cd /d "%~dp0"

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0voicechat-installer.ps1"
set "INSTALL_EXIT_CODE=%ERRORLEVEL%"

echo.
if "%INSTALL_EXIT_CODE%"=="0" (
    echo Press any key to close.
) else (
    echo Installation did not finish. Keep the log file in this folder.
    echo Press any key to close.
)
pause >nul
exit /b %INSTALL_EXIT_CODE%
