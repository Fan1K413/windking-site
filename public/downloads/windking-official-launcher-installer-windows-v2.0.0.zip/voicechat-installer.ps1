﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$MinecraftDirectory = ""
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

try {
    [Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
    [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
    $OutputEncoding = [Console]::OutputEncoding
} catch {
    # The installer can still run if an older console cannot change its encoding.
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.IO.Compression.FileSystem

$script:InstallerVersion = "2.0.0"
$script:MojangManifestUrl = "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json"
$script:FabricMetaApi = "https://meta.fabricmc.net/v2"
$script:ModrinthApi = "https://api.modrinth.com/v2"
$script:ServerName = "风殿下舰长服"
$script:ServerAddress = "windking.fans"
$script:ProfileKey = "windking-fans-fabric"
$script:ApiHeaders = @{
    "User-Agent" = "WindKing-VoiceChat-Installer/$($script:InstallerVersion) (https://windking.fans)"
}
$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$script:LogPath = $null

function Write-Log {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )

    $line = "{0} [{1}] {2}{3}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message, [Environment]::NewLine
    if ($script:LogPath) {
        try {
            [IO.File]::AppendAllText($script:LogPath, $line, $script:Utf8NoBom)
        } catch {
            # Logging must never prevent installation.
        }
    }
}

function Write-Step {
    param([string]$Message)
    Write-Host ("[进行中] {0}" -f $Message) -ForegroundColor Cyan
    Write-Log $Message
}

function Write-Ok {
    param([string]$Message)
    Write-Host ("[完成] {0}" -f $Message) -ForegroundColor Green
    Write-Log $Message
}

function Write-Warn {
    param([string]$Message)
    Write-Host ("[提示] {0}" -f $Message) -ForegroundColor Yellow
    Write-Log $Message "WARN"
}

function Invoke-JsonRequest {
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [Parameter(Mandatory = $true)][string]$Description
    )

    $lastError = $null
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            Write-Log ("请求 {0}（第 {1} 次）" -f $Description, $attempt)
            $response = Invoke-RestMethod -Uri $Uri -Method Get -Headers $script:ApiHeaders -TimeoutSec 45
            Write-Output -NoEnumerate $response
            return
        } catch {
            $lastError = $_
            Write-Log ("请求失败：{0}" -f $_.Exception.Message) "WARN"
            if ($attempt -lt 3) {
                Start-Sleep -Seconds $attempt
            }
        }
    }

    throw "无法连接到$Description。请检查网络或代理后重试。详细信息：$($lastError.Exception.Message)"
}

function Invoke-FileDownload {
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [Parameter(Mandatory = $true)][string]$Destination,
        [Parameter(Mandatory = $true)][string]$Description
    )

    $lastError = $null
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            Write-Log ("下载 {0}（第 {1} 次）" -f $Description, $attempt)
            Invoke-WebRequest -Uri $Uri -Method Get -Headers $script:ApiHeaders -UseBasicParsing -TimeoutSec 120 -OutFile $Destination
            if (-not (Test-Path -LiteralPath $Destination -PathType Leaf)) {
                throw "下载完成后没有找到文件"
            }
            if ((Get-Item -LiteralPath $Destination).Length -le 0) {
                throw "下载得到的是空文件"
            }
            return
        } catch {
            $lastError = $_
            Write-Log ("下载失败：{0}" -f $_.Exception.Message) "WARN"
            if (Test-Path -LiteralPath $Destination) {
                Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
            }
            if ($attempt -lt 3) {
                Start-Sleep -Seconds $attempt
            }
        }
    }

    throw "无法下载$Description。请检查网络或代理后重试。详细信息：$($lastError.Exception.Message)"
}

function Read-JsonDocument {
    param([Parameter(Mandatory = $true)][string]$Path)

    try {
        $raw = [IO.File]::ReadAllText($Path)
        $object = $raw | ConvertFrom-Json
        return [PSCustomObject]@{
            Path = $Path
            Raw = $raw
            Object = $object
        }
    } catch {
        return $null
    }
}

function Get-PropertyValue {
    param(
        [object]$Object,
        [string]$Name
    )

    if ($null -eq $Object) {
        return $null
    }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) {
        return $null
    }
    return $property.Value
}

function Set-ObjectProperty {
    param(
        [Parameter(Mandatory = $true)][object]$Object,
        [Parameter(Mandatory = $true)][string]$Name,
        [object]$Value
    )

    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) {
        $Object | Add-Member -MemberType NoteProperty -Name $Name -Value $Value
    } else {
        $property.Value = $Value
    }
}

function Write-JsonAtomically {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][object]$Object
    )

    $parent = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }

    $temporaryPath = "$Path.windking.tmp"
    try {
        $serialized = $Object | ConvertTo-Json -Depth 100
        [IO.File]::WriteAllText($temporaryPath, $serialized, $script:Utf8NoBom)
        if ($null -eq (Read-JsonDocument $temporaryPath)) {
            throw "写入后的 JSON 校验失败。"
        }
        Move-Item -LiteralPath $temporaryPath -Destination $Path -Force
    } finally {
        if (Test-Path -LiteralPath $temporaryPath) {
            Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
        }
    }
}

function Resolve-MinecraftRoot {
    param([string]$RequestedDirectory)

    if (-not [string]::IsNullOrWhiteSpace($RequestedDirectory)) {
        $resolved = [IO.Path]::GetFullPath($RequestedDirectory).TrimEnd("\", "/")
    } else {
        if ([string]::IsNullOrWhiteSpace($env:APPDATA)) {
            throw "无法读取 Windows APPDATA 目录。"
        }
        $resolved = Join-Path $env:APPDATA ".minecraft"
    }

    if (-not (Test-Path -LiteralPath $resolved -PathType Container)) {
        throw "没有找到官方启动器的 Minecraft 目录：$resolved。请先安装并打开一次 Minecraft 官方启动器。"
    }
    return $resolved
}

function Get-LatestMinecraftRelease {
    Write-Step "正在获取 Minecraft 最新正式版"
    $manifest = Invoke-JsonRequest $script:MojangManifestUrl "Mojang 官方版本服务"
    $latestObject = Get-PropertyValue $manifest "latest"
    $releaseId = [string](Get-PropertyValue $latestObject "release")
    if ([string]::IsNullOrWhiteSpace($releaseId)) {
        throw "Mojang 官方版本服务没有返回 latest.release。"
    }

    $releaseEntry = $null
    foreach ($entry in @((Get-PropertyValue $manifest "versions"))) {
        if ([string](Get-PropertyValue $entry "id") -eq $releaseId) {
            $releaseEntry = $entry
            break
        }
    }
    if ($null -eq $releaseEntry) {
        throw "Mojang 版本列表中没有找到最新正式版 $releaseId。"
    }

    $metadataUrl = [string](Get-PropertyValue $releaseEntry "url")
    if ([string]::IsNullOrWhiteSpace($metadataUrl)) {
        throw "Mojang 没有提供 Minecraft $releaseId 的版本配置地址。"
    }

    Write-Ok ("Minecraft 最新正式版：{0}" -f $releaseId)
    return [PSCustomObject]@{
        Version = $releaseId
        MetadataUrl = $metadataUrl
    }
}

function Ensure-VanillaVersionProfile {
    param(
        [Parameter(Mandatory = $true)][string]$GameRoot,
        [Parameter(Mandatory = $true)][object]$MinecraftRelease
    )

    $version = [string]$MinecraftRelease.Version
    $versionDirectory = Join-Path (Join-Path $GameRoot "versions") $version
    $versionJson = Join-Path $versionDirectory "$version.json"

    if (Test-Path -LiteralPath $versionJson -PathType Leaf) {
        $existing = Read-JsonDocument $versionJson
        if ($null -eq $existing -or [string](Get-PropertyValue $existing.Object "id") -ne $version) {
            throw "已有的 Minecraft $version 版本 JSON 无法安全读取。脚本不会覆盖它：$versionJson"
        }
        Write-Ok ("已存在 Minecraft {0} 基础版本" -f $version)
        return
    }

    if (-not (Test-Path -LiteralPath $versionDirectory -PathType Container)) {
        New-Item -ItemType Directory -Path $versionDirectory -Force | Out-Null
    }

    $temporaryPath = "$versionJson.windking.download"
    try {
        Write-Step ("正在准备 Minecraft {0} 基础版本" -f $version)
        Invoke-FileDownload $MinecraftRelease.MetadataUrl $temporaryPath "Minecraft 官方版本配置"
        $downloaded = Read-JsonDocument $temporaryPath
        if ($null -eq $downloaded -or [string](Get-PropertyValue $downloaded.Object "id") -ne $version) {
            throw "下载的 Minecraft 版本配置校验失败。"
        }
        Move-Item -LiteralPath $temporaryPath -Destination $versionJson -Force
        Write-Ok ("Minecraft {0} 基础版本已准备好" -f $version)
    } finally {
        if (Test-Path -LiteralPath $temporaryPath) {
            Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
        }
    }
}

function Get-LatestFabricProfile {
    param([Parameter(Mandatory = $true)][string]$MinecraftVersion)

    Write-Step ("正在获取 Minecraft {0} 可用的最新 Fabric 正式版" -f $MinecraftVersion)
    $encodedMinecraftVersion = [Uri]::EscapeDataString($MinecraftVersion)
    $loaderResponse = Invoke-JsonRequest "$($script:FabricMetaApi)/versions/loader/$encodedMinecraftVersion" "Fabric 官方版本服务"
    $compatibleLoaders = @($loaderResponse | ForEach-Object { $_ })
    if ($compatibleLoaders.Count -eq 0) {
        throw "Fabric 目前还不支持 Minecraft 最新正式版 $MinecraftVersion。请稍后再试。"
    }

    $stableLoaders = New-Object System.Collections.ArrayList
    foreach ($candidate in $compatibleLoaders) {
        $loaderObject = Get-PropertyValue $candidate "loader"
        if ((Get-PropertyValue $loaderObject "stable") -eq $true) {
            [void]$stableLoaders.Add($candidate)
        }
    }
    if ($stableLoaders.Count -eq 0) {
        throw "Minecraft $MinecraftVersion 目前只有 Fabric 测试版，脚本不会自动安装测试版。"
    }

    $selectedLoader = @(
        $stableLoaders.ToArray() |
            Sort-Object {
                $candidateLoader = Get-PropertyValue $_ "loader"
                $candidateVersion = [string](Get-PropertyValue $candidateLoader "version")
                try {
                    [version]$candidateVersion
                } catch {
                    [version]"0.0"
                }
            } -Descending
    )[0]
    $selectedLoaderObject = Get-PropertyValue $selectedLoader "loader"
    $loaderVersion = [string](Get-PropertyValue $selectedLoaderObject "version")
    if ([string]::IsNullOrWhiteSpace($loaderVersion)) {
        throw "Fabric 官方版本服务没有返回有效的 Loader 版本。"
    }

    $encodedLoaderVersion = [Uri]::EscapeDataString($loaderVersion)
    $profileUrl = "$($script:FabricMetaApi)/versions/loader/$encodedMinecraftVersion/$encodedLoaderVersion/profile/json"
    $profile = Invoke-JsonRequest $profileUrl "Fabric 官方启动配置"

    $profileId = [string](Get-PropertyValue $profile "id")
    $inheritsFrom = [string](Get-PropertyValue $profile "inheritsFrom")
    $mainClass = [string](Get-PropertyValue $profile "mainClass")
    if (
        [string]::IsNullOrWhiteSpace($profileId) -or
        $inheritsFrom -ne $MinecraftVersion -or
        $mainClass -notmatch "(?i)fabric"
    ) {
        throw "Fabric 官方启动配置校验失败。"
    }
    if ($profileId.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0) {
        throw "Fabric 返回的版本名称不能用作 Windows 目录名。"
    }

    Write-Ok ("Fabric Loader 最新稳定版：{0}" -f $loaderVersion)
    return [PSCustomObject]@{
        LoaderVersion = $loaderVersion
        ProfileId = $profileId
        Profile = $profile
    }
}

function Get-MavenLibraryInfo {
    param([Parameter(Mandatory = $true)][object]$Library)

    $downloads = Get-PropertyValue $Library "downloads"
    $artifact = Get-PropertyValue $downloads "artifact"
    $artifactUrl = [string](Get-PropertyValue $artifact "url")
    $artifactPath = [string](Get-PropertyValue $artifact "path")
    if (-not [string]::IsNullOrWhiteSpace($artifactUrl) -and -not [string]::IsNullOrWhiteSpace($artifactPath)) {
        return [PSCustomObject]@{
            Url = $artifactUrl
            RelativePath = $artifactPath.Replace("/", "\")
            Sha1 = [string](Get-PropertyValue $artifact "sha1")
        }
    }

    $name = [string](Get-PropertyValue $Library "name")
    if ([string]::IsNullOrWhiteSpace($name)) {
        return $null
    }

    $extension = "jar"
    $coordinate = $name
    $atIndex = $coordinate.LastIndexOf("@")
    if ($atIndex -gt 0) {
        $extension = $coordinate.Substring($atIndex + 1)
        $coordinate = $coordinate.Substring(0, $atIndex)
    }

    $parts = @($coordinate.Split(":"))
    if ($parts.Count -lt 3 -or $parts.Count -gt 4) {
        return $null
    }

    $group = $parts[0]
    $artifactName = $parts[1]
    $version = $parts[2]
    $classifier = if ($parts.Count -eq 4) { "-$($parts[3])" } else { "" }
    $fileName = "$artifactName-$version$classifier.$extension"
    $relativeUrl = "{0}/{1}/{2}/{3}" -f $group.Replace(".", "/"), $artifactName, $version, $fileName
    $baseUrl = [string](Get-PropertyValue $Library "url")
    if ([string]::IsNullOrWhiteSpace($baseUrl)) {
        $baseUrl = "https://maven.fabricmc.net/"
    }

    return [PSCustomObject]@{
        Url = $baseUrl.TrimEnd("/") + "/" + $relativeUrl
        RelativePath = $relativeUrl.Replace("/", "\")
        Sha1 = $null
    }
}

function Install-FabricLibraries {
    param(
        [Parameter(Mandatory = $true)][string]$GameRoot,
        [array]$Libraries
    )

    $librariesRoot = Join-Path $GameRoot "libraries"
    if (-not (Test-Path -LiteralPath $librariesRoot -PathType Container)) {
        New-Item -ItemType Directory -Path $librariesRoot -Force | Out-Null
    }

    foreach ($library in @($Libraries)) {
        $info = Get-MavenLibraryInfo $library
        if ($null -eq $info) {
            throw "Fabric 配置中存在无法识别的依赖项。"
        }

        $destination = Join-Path $librariesRoot $info.RelativePath
        if (Test-Path -LiteralPath $destination -PathType Leaf) {
            if ([string]::IsNullOrWhiteSpace($info.Sha1)) {
                continue
            }
            $existingHash = (Get-FileHash -LiteralPath $destination -Algorithm SHA1).Hash.ToLowerInvariant()
            if ($existingHash -eq $info.Sha1.ToLowerInvariant()) {
                continue
            }
        }

        $parent = Split-Path -Parent $destination
        if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
        }

        $temporaryFile = "$destination.windking.download"
        Invoke-FileDownload $info.Url $temporaryFile ("Fabric 依赖 " + [IO.Path]::GetFileName($destination))
        if (-not [string]::IsNullOrWhiteSpace($info.Sha1)) {
            $downloadedHash = (Get-FileHash -LiteralPath $temporaryFile -Algorithm SHA1).Hash.ToLowerInvariant()
            if ($downloadedHash -ne $info.Sha1.ToLowerInvariant()) {
                Remove-Item -LiteralPath $temporaryFile -Force -ErrorAction SilentlyContinue
                throw "Fabric 依赖校验失败：$([IO.Path]::GetFileName($destination))"
            }
        }
        Move-Item -LiteralPath $temporaryFile -Destination $destination -Force
    }
}

function Install-FabricVersion {
    param(
        [Parameter(Mandatory = $true)][string]$GameRoot,
        [Parameter(Mandatory = $true)][object]$FabricRelease
    )

    $profile = $FabricRelease.Profile
    $profileId = [string]$FabricRelease.ProfileId
    $versionDirectory = Join-Path (Join-Path $GameRoot "versions") $profileId
    $versionJson = Join-Path $versionDirectory "$profileId.json"
    $libraries = @((Get-PropertyValue $profile "libraries"))
    if ($libraries.Count -eq 0) {
        throw "Fabric 官方启动配置中没有 Loader 依赖。"
    }

    Write-Step "正在下载 Fabric Loader 依赖"
    Install-FabricLibraries $GameRoot $libraries

    if (-not (Test-Path -LiteralPath $versionDirectory -PathType Container)) {
        New-Item -ItemType Directory -Path $versionDirectory -Force | Out-Null
    }

    if (Test-Path -LiteralPath $versionJson -PathType Leaf) {
        $existing = Read-JsonDocument $versionJson
        if (
            $null -eq $existing -or
            [string](Get-PropertyValue $existing.Object "id") -ne $profileId -or
            [string](Get-PropertyValue $existing.Object "mainClass") -notmatch "(?i)fabric"
        ) {
            throw "同名 Fabric 版本已经存在，但配置无法安全读取。脚本不会覆盖它：$versionJson"
        }
        Write-Ok ("已存在 Fabric 游戏版本：{0}" -f $profileId)
    } else {
        Write-JsonAtomically $versionJson $profile
        Write-Ok ("已新建 Fabric 游戏版本：{0}" -f $profileId)
    }

    return [PSCustomObject]@{
        VersionDirectory = $versionDirectory
        VersionJson = $versionJson
    }
}

function Get-LatestVoiceChatRelease {
    param([Parameter(Mandatory = $true)][string]$MinecraftVersion)

    Write-Step ("正在获取 Minecraft {0} / Fabric 对应的最新语音模组正式版" -f $MinecraftVersion)
    $loaderFilter = [Uri]::EscapeDataString('["fabric"]')
    $versionFilter = [Uri]::EscapeDataString(('["{0}"]' -f $MinecraftVersion))
    $uri = "$($script:ModrinthApi)/project/simple-voice-chat/version?loaders=$loaderFilter&game_versions=$versionFilter"
    $versionResponse = Invoke-JsonRequest $uri "Modrinth 模组版本服务"
    $versions = @($versionResponse | ForEach-Object { $_ })
    $releases = @(
        $versions |
            Where-Object { [string](Get-PropertyValue $_ "version_type") -eq "release" } |
            Sort-Object { [DateTime](Get-PropertyValue $_ "date_published") } -Descending
    )
    if ($releases.Count -eq 0) {
        throw "Simple Voice Chat 目前还没有适用于 Minecraft $MinecraftVersion / Fabric 的正式版。脚本不会安装测试版。"
    }

    $selectedVersion = $releases[0]
    $files = @((Get-PropertyValue $selectedVersion "files"))
    $jarFiles = @($files | Where-Object { [string](Get-PropertyValue $_ "filename") -match "(?i)\.jar$" })
    if ($jarFiles.Count -eq 0) {
        throw "Modrinth 返回的语音模组正式版中没有 JAR 文件。"
    }

    $selectedFile = $null
    foreach ($candidate in $jarFiles) {
        if ((Get-PropertyValue $candidate "primary") -eq $true) {
            $selectedFile = $candidate
            break
        }
    }
    if ($null -eq $selectedFile) {
        $selectedFile = $jarFiles[0]
    }

    $hashes = Get-PropertyValue $selectedFile "hashes"
    $downloadUrl = [string](Get-PropertyValue $selectedFile "url")
    $fileName = [IO.Path]::GetFileName([string](Get-PropertyValue $selectedFile "filename"))
    if ([string]::IsNullOrWhiteSpace($downloadUrl) -or [string]::IsNullOrWhiteSpace($fileName)) {
        throw "Modrinth 返回的语音模组下载信息不完整。"
    }

    $releaseName = [string](Get-PropertyValue $selectedVersion "version_number")
    Write-Ok ("Simple Voice Chat 最新正式版：{0}" -f $releaseName)
    return [PSCustomObject]@{
        VersionName = $releaseName
        FileName = $fileName
        DownloadUrl = $downloadUrl
        Sha512 = [string](Get-PropertyValue $hashes "sha512")
    }
}

function Install-VoiceChatMod {
    param(
        [Parameter(Mandatory = $true)][string]$ModsDirectory,
        [Parameter(Mandatory = $true)][object]$Release
    )

    if (-not (Test-Path -LiteralPath $ModsDirectory -PathType Container)) {
        New-Item -ItemType Directory -Path $ModsDirectory -Force | Out-Null
    }

    $destination = Join-Path $ModsDirectory $Release.FileName
    if (
        (Test-Path -LiteralPath $destination -PathType Leaf) -and
        -not [string]::IsNullOrWhiteSpace($Release.Sha512)
    ) {
        $existingHash = (Get-FileHash -LiteralPath $destination -Algorithm SHA512).Hash.ToLowerInvariant()
        if ($existingHash -eq $Release.Sha512.ToLowerInvariant()) {
            Write-Ok ("已安装最新语音模组：{0}" -f $Release.FileName)
            return
        }
    }

    $temporaryFile = Join-Path ([IO.Path]::GetTempPath()) ("windking-voicechat-" + [Guid]::NewGuid().ToString("N") + ".jar")
    try {
        Write-Step ("正在下载 Simple Voice Chat {0}" -f $Release.VersionName)
        Invoke-FileDownload $Release.DownloadUrl $temporaryFile "Simple Voice Chat"

        if ([string]::IsNullOrWhiteSpace($Release.Sha512)) {
            throw "Modrinth 没有提供 SHA-512 校验值，脚本已拒绝安装。"
        }
        $actualHash = (Get-FileHash -LiteralPath $temporaryFile -Algorithm SHA512).Hash.ToLowerInvariant()
        if ($actualHash -ne $Release.Sha512.ToLowerInvariant()) {
            throw "下载文件的 SHA-512 校验失败，脚本已拒绝安装。"
        }
        Write-Log "Simple Voice Chat SHA-512 校验通过"

        $oldFiles = @(
            Get-ChildItem -LiteralPath $ModsDirectory -Filter "*.jar" -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match "(?i)^voicechat-(fabric|forge|neoforge|quilt)-.+\.jar$" }
        )
        $backupDirectory = Join-Path $ModsDirectory (".voicechat-installer-backup\" + (Get-Date -Format "yyyyMMdd-HHmmss"))
        $movedFiles = New-Object System.Collections.Generic.List[object]
        try {
            if ($oldFiles.Count -gt 0) {
                New-Item -ItemType Directory -Path $backupDirectory -Force | Out-Null
                foreach ($oldFile in $oldFiles) {
                    $backupPath = Join-Path $backupDirectory $oldFile.Name
                    Move-Item -LiteralPath $oldFile.FullName -Destination $backupPath -Force
                    [void]$movedFiles.Add([PSCustomObject]@{
                        Original = $oldFile.FullName
                        Backup = $backupPath
                    })
                }
                Write-Warn ("旧版语音模组已备份到：{0}" -f $backupDirectory)
            }
            Move-Item -LiteralPath $temporaryFile -Destination $destination -Force
        } catch {
            foreach ($moved in $movedFiles) {
                if ((Test-Path -LiteralPath $moved.Backup) -and -not (Test-Path -LiteralPath $moved.Original)) {
                    Move-Item -LiteralPath $moved.Backup -Destination $moved.Original -ErrorAction SilentlyContinue
                }
            }
            throw
        }

        Write-Ok ("语音模组已放入新版本：{0}" -f $destination)
    } finally {
        if (Test-Path -LiteralPath $temporaryFile) {
            Remove-Item -LiteralPath $temporaryFile -Force -ErrorAction SilentlyContinue
        }
    }
}

function Read-NbtBytes {
    param(
        [Parameter(Mandatory = $true)][IO.BinaryReader]$Reader,
        [Parameter(Mandatory = $true)][int]$Length
    )

    if ($Length -lt 0 -or $Length -gt 67108864) {
        throw "NBT 数据长度无效：$Length"
    }
    $bytes = $Reader.ReadBytes($Length)
    if ($bytes.Length -ne $Length) {
        throw "servers.dat 文件不完整。"
    }
    return ,$bytes
}

function Read-NbtInt16 {
    param([Parameter(Mandatory = $true)][IO.BinaryReader]$Reader)
    $bytes = Read-NbtBytes $Reader 2
    [Array]::Reverse($bytes)
    return [BitConverter]::ToInt16($bytes, 0)
}

function Read-NbtUInt16 {
    param([Parameter(Mandatory = $true)][IO.BinaryReader]$Reader)
    $bytes = Read-NbtBytes $Reader 2
    [Array]::Reverse($bytes)
    return [BitConverter]::ToUInt16($bytes, 0)
}

function Read-NbtInt32 {
    param([Parameter(Mandatory = $true)][IO.BinaryReader]$Reader)
    $bytes = Read-NbtBytes $Reader 4
    [Array]::Reverse($bytes)
    return [BitConverter]::ToInt32($bytes, 0)
}

function Read-NbtInt64 {
    param([Parameter(Mandatory = $true)][IO.BinaryReader]$Reader)
    $bytes = Read-NbtBytes $Reader 8
    [Array]::Reverse($bytes)
    return [BitConverter]::ToInt64($bytes, 0)
}

function Read-NbtSingle {
    param([Parameter(Mandatory = $true)][IO.BinaryReader]$Reader)
    $bytes = Read-NbtBytes $Reader 4
    [Array]::Reverse($bytes)
    return [BitConverter]::ToSingle($bytes, 0)
}

function Read-NbtDouble {
    param([Parameter(Mandatory = $true)][IO.BinaryReader]$Reader)
    $bytes = Read-NbtBytes $Reader 8
    [Array]::Reverse($bytes)
    return [BitConverter]::ToDouble($bytes, 0)
}

function Read-NbtString {
    param([Parameter(Mandatory = $true)][IO.BinaryReader]$Reader)
    $length = Read-NbtUInt16 $Reader
    $bytes = Read-NbtBytes $Reader $length
    return [Text.Encoding]::UTF8.GetString($bytes)
}

function Read-NbtPayload {
    param(
        [Parameter(Mandatory = $true)][IO.BinaryReader]$Reader,
        [Parameter(Mandatory = $true)][int]$Type,
        [int]$Depth = 0
    )

    if ($Depth -gt 64) {
        throw "servers.dat 的 NBT 嵌套过深。"
    }

    switch ($Type) {
        1 {
            return [PSCustomObject]@{ Data = $Reader.ReadSByte() }
        }
        2 {
            return [PSCustomObject]@{ Data = Read-NbtInt16 $Reader }
        }
        3 {
            return [PSCustomObject]@{ Data = Read-NbtInt32 $Reader }
        }
        4 {
            return [PSCustomObject]@{ Data = Read-NbtInt64 $Reader }
        }
        5 {
            return [PSCustomObject]@{ Data = Read-NbtSingle $Reader }
        }
        6 {
            return [PSCustomObject]@{ Data = Read-NbtDouble $Reader }
        }
        7 {
            $length = Read-NbtInt32 $Reader
            return [PSCustomObject]@{ Data = Read-NbtBytes $Reader $length }
        }
        8 {
            return [PSCustomObject]@{ Data = Read-NbtString $Reader }
        }
        9 {
            $elementType = [int]$Reader.ReadByte()
            $length = Read-NbtInt32 $Reader
            if ($length -lt 0 -or $length -gt 100000) {
                throw "servers.dat 的 NBT 列表长度无效：$length"
            }
            $items = New-Object System.Collections.ArrayList
            for ($index = 0; $index -lt $length; $index++) {
                [void]$items.Add((Read-NbtPayload $Reader $elementType ($Depth + 1)))
            }
            return [PSCustomObject]@{
                ElementType = $elementType
                Items = $items.ToArray()
            }
        }
        10 {
            $tags = New-Object System.Collections.ArrayList
            while ($true) {
                $childType = [int]$Reader.ReadByte()
                if ($childType -eq 0) {
                    break
                }
                $childName = Read-NbtString $Reader
                $childValue = Read-NbtPayload $Reader $childType ($Depth + 1)
                [void]$tags.Add([PSCustomObject]@{
                    Type = $childType
                    Name = $childName
                    Value = $childValue
                })
            }
            return [PSCustomObject]@{ Tags = $tags.ToArray() }
        }
        11 {
            $length = Read-NbtInt32 $Reader
            if ($length -lt 0 -or $length -gt 1000000) {
                throw "servers.dat 的 NBT 整数数组长度无效：$length"
            }
            $items = New-Object System.Collections.ArrayList
            for ($index = 0; $index -lt $length; $index++) {
                [void]$items.Add((Read-NbtInt32 $Reader))
            }
            return [PSCustomObject]@{ Data = $items.ToArray() }
        }
        12 {
            $length = Read-NbtInt32 $Reader
            if ($length -lt 0 -or $length -gt 1000000) {
                throw "servers.dat 的 NBT 长整数数组长度无效：$length"
            }
            $items = New-Object System.Collections.ArrayList
            for ($index = 0; $index -lt $length; $index++) {
                [void]$items.Add((Read-NbtInt64 $Reader))
            }
            return [PSCustomObject]@{ Data = $items.ToArray() }
        }
        default {
            throw "servers.dat 包含不支持的 NBT 类型：$Type"
        }
    }
}

function Read-NbtDocument {
    param([Parameter(Mandatory = $true)][string]$Path)

    $stream = $null
    $reader = $null
    try {
        $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::Read)
        $reader = New-Object IO.BinaryReader($stream)
        $rootType = [int]$reader.ReadByte()
        if ($rootType -ne 10) {
            throw "servers.dat 的根标签不是 NBT Compound。"
        }
        $rootName = Read-NbtString $reader
        $rootValue = Read-NbtPayload $reader $rootType 0
        if ($stream.Position -ne $stream.Length) {
            throw "servers.dat 尾部包含无法识别的数据。"
        }
        return [PSCustomObject]@{
            Type = $rootType
            Name = $rootName
            Value = $rootValue
        }
    } finally {
        if ($null -ne $reader) {
            $reader.Dispose()
        } elseif ($null -ne $stream) {
            $stream.Dispose()
        }
    }
}

function Write-NbtBytesReversed {
    param(
        [Parameter(Mandatory = $true)][IO.BinaryWriter]$Writer,
        [Parameter(Mandatory = $true)][byte[]]$Bytes
    )
    [Array]::Reverse($Bytes)
    $Writer.Write($Bytes)
}

function Write-NbtInt16 {
    param([IO.BinaryWriter]$Writer, [int16]$Value)
    Write-NbtBytesReversed $Writer ([BitConverter]::GetBytes($Value))
}

function Write-NbtUInt16 {
    param([IO.BinaryWriter]$Writer, [uint16]$Value)
    Write-NbtBytesReversed $Writer ([BitConverter]::GetBytes($Value))
}

function Write-NbtInt32 {
    param([IO.BinaryWriter]$Writer, [int32]$Value)
    Write-NbtBytesReversed $Writer ([BitConverter]::GetBytes($Value))
}

function Write-NbtInt64 {
    param([IO.BinaryWriter]$Writer, [int64]$Value)
    Write-NbtBytesReversed $Writer ([BitConverter]::GetBytes($Value))
}

function Write-NbtSingle {
    param([IO.BinaryWriter]$Writer, [single]$Value)
    Write-NbtBytesReversed $Writer ([BitConverter]::GetBytes($Value))
}

function Write-NbtDouble {
    param([IO.BinaryWriter]$Writer, [double]$Value)
    Write-NbtBytesReversed $Writer ([BitConverter]::GetBytes($Value))
}

function Write-NbtString {
    param(
        [Parameter(Mandatory = $true)][IO.BinaryWriter]$Writer,
        [AllowEmptyString()][string]$Value
    )

    $bytes = [Text.Encoding]::UTF8.GetBytes($Value)
    if ($bytes.Length -gt 65535) {
        throw "NBT 字符串过长。"
    }
    Write-NbtUInt16 $Writer ([uint16]$bytes.Length)
    $Writer.Write($bytes)
}

function Write-NbtPayload {
    param(
        [Parameter(Mandatory = $true)][IO.BinaryWriter]$Writer,
        [Parameter(Mandatory = $true)][int]$Type,
        [Parameter(Mandatory = $true)][object]$Value
    )

    switch ($Type) {
        1 {
            $Writer.Write([sbyte]$Value.Data)
        }
        2 {
            Write-NbtInt16 $Writer ([int16]$Value.Data)
        }
        3 {
            Write-NbtInt32 $Writer ([int32]$Value.Data)
        }
        4 {
            Write-NbtInt64 $Writer ([int64]$Value.Data)
        }
        5 {
            Write-NbtSingle $Writer ([single]$Value.Data)
        }
        6 {
            Write-NbtDouble $Writer ([double]$Value.Data)
        }
        7 {
            $bytes = [byte[]]$Value.Data
            Write-NbtInt32 $Writer $bytes.Length
            $Writer.Write($bytes)
        }
        8 {
            Write-NbtString $Writer ([string]$Value.Data)
        }
        9 {
            $Writer.Write([byte]$Value.ElementType)
            $items = @($Value.Items)
            Write-NbtInt32 $Writer $items.Count
            foreach ($item in $items) {
                Write-NbtPayload $Writer ([int]$Value.ElementType) $item
            }
        }
        10 {
            foreach ($tag in @($Value.Tags)) {
                Write-NbtNamedTag $Writer $tag
            }
            $Writer.Write([byte]0)
        }
        11 {
            $items = @($Value.Data)
            Write-NbtInt32 $Writer $items.Count
            foreach ($item in $items) {
                Write-NbtInt32 $Writer ([int32]$item)
            }
        }
        12 {
            $items = @($Value.Data)
            Write-NbtInt32 $Writer $items.Count
            foreach ($item in $items) {
                Write-NbtInt64 $Writer ([int64]$item)
            }
        }
        default {
            throw "无法写入不支持的 NBT 类型：$Type"
        }
    }
}

function Write-NbtNamedTag {
    param(
        [Parameter(Mandatory = $true)][IO.BinaryWriter]$Writer,
        [Parameter(Mandatory = $true)][object]$Tag
    )

    $Writer.Write([byte]$Tag.Type)
    Write-NbtString $Writer ([string]$Tag.Name)
    Write-NbtPayload $Writer ([int]$Tag.Type) $Tag.Value
}

function Write-NbtDocument {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][object]$Document
    )

    $stream = $null
    $writer = $null
    try {
        $stream = [IO.File]::Open($Path, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $writer = New-Object IO.BinaryWriter($stream)
        $writer.Write([byte]$Document.Type)
        Write-NbtString $writer ([string]$Document.Name)
        Write-NbtPayload $writer ([int]$Document.Type) $Document.Value
        $writer.Flush()
    } finally {
        if ($null -ne $writer) {
            $writer.Dispose()
        } elseif ($null -ne $stream) {
            $stream.Dispose()
        }
    }
}

function New-StringNbtTag {
    param([string]$Name, [string]$Value)
    return [PSCustomObject]@{
        Type = 8
        Name = $Name
        Value = [PSCustomObject]@{ Data = $Value }
    }
}

function New-WindKingServerEntry {
    $tags = New-Object System.Collections.ArrayList
    [void]$tags.Add((New-StringNbtTag "name" $script:ServerName))
    [void]$tags.Add((New-StringNbtTag "ip" $script:ServerAddress))
    return [PSCustomObject]@{ Tags = $tags.ToArray() }
}

function Test-NbtContainsServer {
    param(
        [Parameter(Mandatory = $true)][object]$Document,
        [Parameter(Mandatory = $true)][string]$Address
    )

    foreach ($tag in @($Document.Value.Tags)) {
        if ([int]$tag.Type -ne 9 -or [string]$tag.Name -ne "servers") {
            continue
        }
        if ([int]$tag.Value.ElementType -ne 10) {
            return $false
        }
        foreach ($entry in @($tag.Value.Items)) {
            foreach ($entryTag in @($entry.Tags)) {
                if (
                    [int]$entryTag.Type -eq 8 -and
                    [string]$entryTag.Name -eq "ip" -and
                    [string]$entryTag.Value.Data -ieq $Address
                ) {
                    return $true
                }
            }
        }
    }
    return $false
}

function Add-WindKingServer {
    param([Parameter(Mandatory = $true)][string]$GameDirectory)

    $serversPath = Join-Path $GameDirectory "servers.dat"
    $backupPath = $null

    if (Test-Path -LiteralPath $serversPath -PathType Leaf) {
        $document = Read-NbtDocument $serversPath
        if (Test-NbtContainsServer $document $script:ServerAddress) {
            Write-Ok ("多人游戏列表中已存在：{0}" -f $script:ServerAddress)
            return
        }
    } else {
        $document = [PSCustomObject]@{
            Type = 10
            Name = ""
            Value = [PSCustomObject]@{ Tags = @() }
        }
    }

    $serversTag = $null
    foreach ($tag in @($document.Value.Tags)) {
        if ([string]$tag.Name -eq "servers") {
            if ([int]$tag.Type -ne 9 -or [int]$tag.Value.ElementType -ne 10) {
                throw "现有 servers.dat 的 servers 标签格式无法安全修改。"
            }
            $serversTag = $tag
            break
        }
    }

    if ($null -eq $serversTag) {
        $serversTag = [PSCustomObject]@{
            Type = 9
            Name = "servers"
            Value = [PSCustomObject]@{
                ElementType = 10
                Items = @()
            }
        }
        $rootTags = New-Object System.Collections.ArrayList
        foreach ($tag in @($document.Value.Tags)) {
            [void]$rootTags.Add($tag)
        }
        [void]$rootTags.Add($serversTag)
        $document.Value.Tags = $rootTags.ToArray()
    }

    $serverEntries = New-Object System.Collections.ArrayList
    foreach ($entry in @($serversTag.Value.Items)) {
        [void]$serverEntries.Add($entry)
    }
    [void]$serverEntries.Add((New-WindKingServerEntry))
    $serversTag.Value.Items = $serverEntries.ToArray()

    $temporaryPath = "$serversPath.windking.tmp"
    try {
        Write-NbtDocument $temporaryPath $document
        $validated = Read-NbtDocument $temporaryPath
        if (-not (Test-NbtContainsServer $validated $script:ServerAddress)) {
            throw "写入后的多人游戏列表校验失败。"
        }

        if (Test-Path -LiteralPath $serversPath -PathType Leaf) {
            $backupPath = "$serversPath.windking-backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
            Copy-Item -LiteralPath $serversPath -Destination $backupPath
        }
        Move-Item -LiteralPath $temporaryPath -Destination $serversPath -Force
    } finally {
        if (Test-Path -LiteralPath $temporaryPath) {
            Remove-Item -LiteralPath $temporaryPath -Force -ErrorAction SilentlyContinue
        }
    }

    if ($backupPath) {
        Write-Warn ("原多人游戏列表已备份到：{0}" -f $backupPath)
    }
    Write-Ok ("已加入多人游戏列表：{0}（{1}）" -f $script:ServerName, $script:ServerAddress)
}

function Update-LauncherProfileFile {
    param(
        [Parameter(Mandatory = $true)][string]$ProfilePath,
        [Parameter(Mandatory = $true)][string]$MinecraftVersion,
        [Parameter(Mandatory = $true)][string]$FabricVersionId,
        [Parameter(Mandatory = $true)][string]$IsolatedGameDirectory
    )

    $fileExisted = Test-Path -LiteralPath $ProfilePath -PathType Leaf
    if ($fileExisted) {
        $document = Read-JsonDocument $ProfilePath
        if ($null -eq $document) {
            throw "官方启动器配置无法安全读取，脚本不会覆盖它：$ProfilePath"
        }
        $root = $document.Object
    } else {
        $root = New-Object PSObject
    }

    $profiles = Get-PropertyValue $root "profiles"
    if ($null -eq $profiles) {
        $profiles = New-Object PSObject
        Set-ObjectProperty $root "profiles" $profiles
    }

    $now = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    $profile = [PSCustomObject]@{
        created = $now
        gameDir = $IsolatedGameDirectory
        lastUsed = $now
        lastVersionId = $FabricVersionId
        name = "风殿下舰长服 Fabric $MinecraftVersion"
        type = "custom"
    }
    Set-ObjectProperty $profiles $script:ProfileKey $profile
    Set-ObjectProperty $root "selectedProfile" $script:ProfileKey

    $backupPath = $null
    if ($fileExisted) {
        $backupPath = "$ProfilePath.windking-backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        Copy-Item -LiteralPath $ProfilePath -Destination $backupPath
    }
    Write-JsonAtomically $ProfilePath $root
    if ($backupPath) {
        Write-Log ("启动器配置备份：{0}" -f $backupPath)
    }
    Write-Ok ("已在官方启动器中创建配置：风殿下舰长服 Fabric {0}" -f $MinecraftVersion)
}

function Update-LauncherProfiles {
    param(
        [Parameter(Mandatory = $true)][string]$GameRoot,
        [Parameter(Mandatory = $true)][string]$MinecraftVersion,
        [Parameter(Mandatory = $true)][string]$FabricVersionId,
        [Parameter(Mandatory = $true)][string]$IsolatedGameDirectory
    )

    $candidatePaths = @(
        (Join-Path $GameRoot "launcher_profiles.json"),
        (Join-Path $GameRoot "launcher_profiles_microsoft_store.json")
    )
    $existingPaths = @($candidatePaths | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf })
    $targetPaths = if ($existingPaths.Count -gt 0) {
        $existingPaths
    } else {
        @($candidatePaths[0])
    }

    foreach ($profilePath in $targetPaths) {
        Update-LauncherProfileFile $profilePath $MinecraftVersion $FabricVersionId $IsolatedGameDirectory
    }
}

$exitCode = 0
try {
    $scriptDirectory = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd("\", "/")
    if ($scriptDirectory.StartsWith([IO.Path]::GetTempPath(), [StringComparison]::OrdinalIgnoreCase)) {
        throw "当前文件似乎仍在压缩包临时目录中。请先完整解压压缩包，再运行「安装语音模组.bat」。"
    }

    $script:LogPath = Join-Path $scriptDirectory "语音模组安装日志.txt"
    [IO.File]::WriteAllText(
        $script:LogPath,
        ("风殿下舰长服 Fabric + Simple Voice Chat 安装日志{0}安装器版本：{1}{0}开始时间：{2}{0}{0}" -f [Environment]::NewLine, $script:InstallerVersion, (Get-Date -Format "yyyy-MM-dd HH:mm:ss")),
        $script:Utf8NoBom
    )

    Write-Host "本工具仅适用于 Windows 10/11、Minecraft Java 版和官方启动器。" -ForegroundColor DarkGray
    Write-Host "将自动安装 Minecraft、Fabric Loader 和 Simple Voice Chat 的最新正式版。" -ForegroundColor DarkGray
    Write-Host ""

    if (@(Get-Process -Name "MinecraftLauncher" -ErrorAction SilentlyContinue).Count -gt 0) {
        throw "Minecraft 启动器仍在运行。请完全退出启动器后重新双击安装，避免启动器覆盖新配置。"
    }

    $gameRoot = Resolve-MinecraftRoot $MinecraftDirectory
    Write-Log ("Minecraft 根目录：{0}" -f $gameRoot)

    $minecraftRelease = Get-LatestMinecraftRelease
    $fabricRelease = Get-LatestFabricProfile $minecraftRelease.Version
    $voiceChatRelease = Get-LatestVoiceChatRelease $minecraftRelease.Version

    $isolatedGameDirectory = Join-Path $gameRoot "windking-fans"
    if (-not (Test-Path -LiteralPath $isolatedGameDirectory -PathType Container)) {
        New-Item -ItemType Directory -Path $isolatedGameDirectory -Force | Out-Null
    }

    Ensure-VanillaVersionProfile $gameRoot $minecraftRelease
    $fabricInstallation = Install-FabricVersion $gameRoot $fabricRelease

    $modsDirectory = Join-Path $isolatedGameDirectory "mods"
    Install-VoiceChatMod $modsDirectory $voiceChatRelease

    Add-WindKingServer $isolatedGameDirectory
    Update-LauncherProfiles $gameRoot $minecraftRelease.Version $fabricRelease.ProfileId $isolatedGameDirectory

    Write-Host ""
    Write-Host "====================================================" -ForegroundColor Green
    Write-Host "  安装成功" -ForegroundColor Green
    Write-Host "====================================================" -ForegroundColor Green
    Write-Host ("Minecraft：{0}（最新正式版）" -f $minecraftRelease.Version)
    Write-Host ("Fabric Loader：{0}（最新稳定版）" -f $fabricRelease.LoaderVersion)
    Write-Host ("Simple Voice Chat：{0}（最新正式版）" -f $voiceChatRelease.VersionName)
    Write-Host ("服务器：{0}" -f $script:ServerAddress)
    Write-Host ""
    Write-Host "现在打开 Minecraft 官方启动器，直接启动："
    Write-Host ("风殿下舰长服 Fabric {0}" -f $minecraftRelease.Version) -ForegroundColor Yellow
    Write-Host "进入服务器后按 V，按画面提示选择麦克风和扬声器。"
    Write-Host ""
    Write-Log "安装成功"
} catch {
    $exitCode = 1
    $message = $_.Exception.Message
    Write-Log $message "ERROR"
    Write-Host ""
    Write-Host "====================================================" -ForegroundColor Red
    Write-Host "  安装未完成" -ForegroundColor Red
    Write-Host "====================================================" -ForegroundColor Red
    Write-Host $message -ForegroundColor Red
    Write-Host ""
    Write-Host "请确认：" -ForegroundColor Yellow
    Write-Host "1. 压缩包已经完整解压；"
    Write-Host "2. Minecraft 和官方启动器已经完全关闭；"
    Write-Host "3. 电脑可以访问 Mojang、Fabric 与 Modrinth。"
    if ($script:LogPath) {
        Write-Host ("仍无法解决时，请把「{0}」发给技术支持。" -f ([IO.Path]::GetFileName($script:LogPath)))
    }
}

exit $exitCode
